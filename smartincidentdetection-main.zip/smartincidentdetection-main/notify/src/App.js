import logo from './logo.svg';
import './App.css';
import IncidentList from './IncidentList';

function App() {
  return (
    <IncidentList/>
  );
}

export default App;
